<?php

require_once('FormProcessor.php');
FormProcessor::startDiagnostics();